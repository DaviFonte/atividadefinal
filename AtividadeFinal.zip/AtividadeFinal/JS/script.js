let carrinho = [];

function adicionarProduto(id, nome, preco) {
    const produto = { id, nome, preco };
    carrinho.push(produto);
    atualizarCarrinho();
}

function atualizarCarrinho() {
    const listaCarrinho = document.getElementById("carrinho-lista");
    listaCarrinho.innerHTML = ""; // Limpa o carrinho antes de atualizar

    carrinho.forEach((produto, index) => {
        const li = document.createElement("li");
        li.textContent = `${produto.nome} - R$ ${produto.preco.toFixed(2)}`;
        const btnRemover = document.createElement("button");
        btnRemover.textContent = "Remover";
        btnRemover.onclick = () => {
            carrinho.splice(index, 1);
            atualizarCarrinho();
        };
        li.appendChild(btnRemover);
        listaCarrinho.appendChild(li);
    });
}

function finalizarCompra() {
    if (carrinho.length === 0) {
        alert("O carrinho está vazio.");
        return;
    }

    // Envia os dados do carrinho para o PHP
    fetch("../php/finalizar_compra.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(carrinho)
    })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            carrinho = [];
            atualizarCarrinho();
        })
        .catch(error => {
            console.error("Erro ao finalizar a compra:", error);
            alert("Ocorreu um erro ao finalizar a compra.");
        });
}
