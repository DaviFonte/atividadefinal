<?php
// Inclui o arquivo de conexão
include 'db.php';

// Recebe os dados do carrinho (enviados via POST)
$data = json_decode(file_get_contents("php://input"), true);

// Verifica se os dados foram recebidos corretamente
if (!$data) {
    echo json_encode(['message' => 'Dados inválidos.']);
    exit;
}

try {
    // Preparar a query para inserir os dados no banco
    foreach ($data as $produto) {
        $stmt = $pdo->prepare("INSERT INTO vendas (produto_id, produto_nome, produto_preco) 
                               VALUES (?, ?, ?)");
        // Executa a query para salvar a venda
        $stmt->execute([$produto['id'], $produto['nome'], $produto['preco']]);
    }

    // Retorna uma resposta de sucesso
    echo json_encode(['message' => 'Compra finalizada com sucesso!']);
} catch (PDOException $e) {
    // Caso haja erro, exibe a mensagem de erro
    echo json_encode(['message' => 'Erro ao salvar a compra: ' . $e->getMessage()]);
}
?>
