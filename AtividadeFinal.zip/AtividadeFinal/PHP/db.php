<?php
// Configurações do banco de dados
$host = 'localhost';    // Servidor MySQL
$dbname = 'loja';       // Nome do banco de dados
$username = 'root';     // Usuário do banco de dados (padrão no XAMPP é "root")
$password = '';         // Senha (padrão no XAMPP é vazio)

// Tentar conectar ao banco de dados usando PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  // Habilitar exceções em caso de erro
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}
?>
